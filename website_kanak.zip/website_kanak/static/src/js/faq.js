odoo.define('kanak_website.faq', function(require) {
    'use strict';
    $(document).ready(function() {
        $("#myModal").modal('show');
        $(".faq_button_1").click(function(ev) {
            var x = document.getElementById("faq_1");
            var y = document.getElementById("faq_icon_1");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_2").click(function(ev) {
            var x = document.getElementById("faq_2");
            var y = document.getElementById("faq_icon_2");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_3").click(function(ev) {
            var x = document.getElementById("faq_3");
            var y = document.getElementById("faq_icon_3");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_4").click(function(ev) {
            var x = document.getElementById("faq_4");
            var y = document.getElementById("faq_icon_4");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_5").click(function(ev) {
            var x = document.getElementById("faq_5");
            var y = document.getElementById("faq_icon_5");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_6").click(function(ev) {
            var x = document.getElementById("faq_6");
            var y = document.getElementById("faq_icon_6");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_7").click(function(ev) {
            var x = document.getElementById("faq_7");
            var y = document.getElementById("faq_icon_7");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_8").click(function(ev) {
            var x = document.getElementById("faq_8");
            var y = document.getElementById("faq_icon_8");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_9").click(function(ev) {
            var x = document.getElementById("faq_9");
            var y = document.getElementById("faq_icon_9");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_10").click(function(ev) {
            var x = document.getElementById("faq_10");
            var y = document.getElementById("faq_icon_10");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_11").click(function(ev) {
            var x = document.getElementById("faq_11");
            var y = document.getElementById("faq_icon_11");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_12").click(function(ev) {
            var x = document.getElementById("faq_12");
            var y = document.getElementById("faq_icon_12");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_13").click(function(ev) {
            var x = document.getElementById("faq_13");
            var y = document.getElementById("faq_icon_13");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
        $(".faq_button_14").click(function(ev) {
            var x = document.getElementById("faq_14");
            var y = document.getElementById("faq_icon_14");
            if (x.style.display === "none") {
                x.style.display = "block";
                y.style.transform = "rotate(91deg)";
            } else {
                x.style.display = "none";
                y.style.transform = "unset";
            }
        });
    });
});